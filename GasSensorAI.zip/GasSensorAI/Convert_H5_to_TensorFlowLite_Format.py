import tensorflow as tf
from tensorflow import keras


# Convert Classification Model
classification_model = tf.keras.models.load_model("classification_model.h5")
classification_converter = tf.lite.TFLiteConverter.from_keras_model(classification_model)
classification_tflite_model = classification_converter.convert()
with open("classification_model.tflite", "wb") as f:
    f.write(classification_tflite_model)

# Convert Regression Model
regression_model = keras.models.load_model("regression_model.h5", custom_objects={"mse": keras.losses.MeanSquaredError()})
regression_converter = tf.lite.TFLiteConverter.from_keras_model(regression_model)
regression_tflite_model = regression_converter.convert()
with open("regression_model.tflite", "wb") as f:
    f.write(regression_tflite_model)

# Convert Autoencoder Model
autoencoder_model = tf.keras.models.load_model("autoencoder_model.h5", custom_objects={"mse": keras.losses.MeanSquaredError()})
autoencoder_converter = tf.lite.TFLiteConverter.from_keras_model(autoencoder_model)
autoencoder_tflite_model = autoencoder_converter.convert()
with open("autoencoder_model.tflite", "wb") as f:
    f.write(autoencoder_tflite_model)

print("Models successfully converted to TensorFlow Lite!")
