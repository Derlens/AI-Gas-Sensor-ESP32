import tensorflow as tf

# Load the TFLite model
interpreter = tf.lite.Interpreter(model_path="regression_model.tflite")
interpreter.allocate_tensors()

# Get input details
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

# Example input (adjust dimensions as needed)
import numpy as np
sample_input = np.array([[0.5, 0.2, 0.3]], dtype=np.float32)  # Replace with your actual feature values

# Run inference
interpreter.set_tensor(input_details[0]['index'], sample_input)
interpreter.invoke()
output_data = interpreter.get_tensor(output_details[0]['index'])

print("Model loaded successfully!")
print("Model Output:", output_data)
