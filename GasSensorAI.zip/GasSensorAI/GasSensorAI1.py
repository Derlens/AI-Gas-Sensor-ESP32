import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Load dataset (replace 'gas_data.csv' with actual dataset file)
df = pd.read_csv('gas_data_mq135.csv')

# Features and labels (adjust column names accordingly)
features = ['sensor1', 'temperature', 'humidity']
X = df[features].values
y_classification = df['gas_presence'].values  # Binary classification (0 or 1)
y_regression = df['gas_concentration'].values  # PPM values

# Data preprocessing
scaler = StandardScaler() 
X_scaled = scaler.fit_transform(X)

# Train-test split
X_train, X_test, y_train_class, y_test_class = train_test_split(X_scaled, y_classification, test_size=0.2, random_state=42)
X_train, X_test, y_train_reg, y_test_reg = train_test_split(X_scaled, y_regression, test_size=0.2, random_state=42)

# Classification Model
classification_model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(len(features),)),
    layers.Dense(32, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])
classification_model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train classification model
classification_model.fit(X_train, y_train_class, epochs=50, validation_data=(X_test, y_test_class))

# Regression Model
regression_model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(len(features),)),
    layers.Dense(32, activation='relu'),
    layers.Dense(1)  # Predicting continuous values (PPM)
])
regression_model.compile(optimizer='adam', loss=keras.losses.MeanSquaredError(), metrics=['mae'])

# Train regression model
regression_model.fit(X_train, y_train_reg, epochs=50, validation_data=(X_test, y_test_reg))

# Anomaly Detection (Autoencoder)
autoencoder = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(len(features),)),
    layers.Dense(32, activation='relu'),
    layers.Dense(64, activation='relu'),
    layers.Dense(len(features), activation='sigmoid')
])
autoencoder.compile(optimizer='adam', loss=keras.losses.MeanSquaredError())

# Train autoencoder for anomaly detection
autoencoder.fit(X_train, X_train, epochs=50, validation_data=(X_test, X_test))

# Save models for ESP32 deployment
classification_model.save("classification_model.h5")
regression_model.save("regression_model.h5")
autoencoder.save("autoencoder_model.h5")

print("Models trained and saved successfully!")
